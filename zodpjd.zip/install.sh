termux-setup-storage
rm ./storage/shared/ppSR -rf
chmod +x run.sh
rm ppSR_Android.zip
apt install git -y
pkg install python -y
pip install protobuf
pip install dataclasses_json
pip install requests
wget -O build.zip https://files.catbox.moe/eztq6t.zip
unzip -o build.zip
rm build.zip
mkdir ./storage/shared/ppSR/
mkdir ./storage/shared/ppSR/misc/
cp ./build/misc/ ./storage/shared/ppSR/ -rf